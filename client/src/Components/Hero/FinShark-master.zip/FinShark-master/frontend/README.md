# FinShark

FinShark helps investors find relavent financial documents without the noise of short-term data.
