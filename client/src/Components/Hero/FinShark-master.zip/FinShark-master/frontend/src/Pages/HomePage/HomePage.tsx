import React from "react";
import Hero from "../../Components/Hero/Hero";

type Props = {};

const HomePage = (props: Props) => {
  return (
    <>
      <Hero />
    </>
  );
};

export default HomePage;
